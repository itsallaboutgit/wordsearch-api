package org.Selenium.pom.Constants;

public class constants {

    public static final String HOME_PAGE_TITLE = "Book Bus Travels";
}
