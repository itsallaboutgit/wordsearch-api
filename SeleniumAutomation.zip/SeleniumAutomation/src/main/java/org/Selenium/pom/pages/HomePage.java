package org.Selenium.pom.pages;

import org.Selenium.pom.base.BasePage;
import org.Selenium.pom.Constants.constants;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.stream.Stream;

public class HomePage extends BasePage {

    By listOfFromCities = By.xpath("//ul[@class='autoFill homeSearch']");
    By fromCityTextBox = By.xpath("//*[@id='src']");
    By listofToCities =By.xpath("//ul[@class='autoFill homeSearch']");
    By toCityTextBox = By.xpath("//*[@id='dest']");
    By selectCalender = By.xpath("//div[@class='fl search-box date-box gtm-onwardCalendar']");
    By selectTodaysDate = By.xpath("//td[contains(text(),'4')and@class='current day']");
    By searchBusBtn =By.xpath("//button[@id='search_btn']");

    public HomePage(WebDriver driver) {
        super(driver);
    }

    public HomePage chooseFromCity(String fromCitySuggestion,String fromCity) throws InterruptedException {
        driver.findElement(fromCityTextBox).sendKeys(fromCitySuggestion);
        List<WebElement> elements = driver.findElements(listOfFromCities);

        for(WebElement ele : elements){
            if(ele.getText().equalsIgnoreCase(fromCity))
                ele.click();
                break;
        }
        synchronized (driver){
            driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(2));
        }
        driver.findElement(fromCityTextBox).sendKeys(Keys.TAB);
        return this;
    }

   public HomePage chooseToCity(String toCitySuggestion,String toCity){
       driver.findElement(toCityTextBox).sendKeys(toCitySuggestion);
       List<WebElement> elements = driver.findElements(listofToCities);
       for(WebElement ele : elements){
           if(ele.getText().equalsIgnoreCase(toCity))
               ele.click();
           break;
       }
       synchronized (driver){
           driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(2));
           driver.findElement(fromCityTextBox).sendKeys(Keys.TAB);
       }
       return this;
    }

   public HomePage datePicker() throws InterruptedException, ParseException {
       synchronized (driver)
       {
           driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
       }
       driver.findElement(selectCalender).click();
       driver.findElement(selectTodaysDate).click();
       return this;
   }

   public SearchPage clickSearchBusBtn() throws InterruptedException {
       synchronized (driver){
           driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
       }
       driver.switchTo().defaultContent();
       driver.findElement(searchBusBtn).click();
       Thread.sleep(10);
       return new SearchPage(driver);
   }
}
