package org.Selenium.pom.pages;

import org.Selenium.pom.base.BasePage;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;

import java.util.Set;

public class SearchPage extends BasePage {

    By clickViewSeat = By.xpath("(//div[@class='button view-seats fr'])[1]");
    By closePopUp = By.xpath("//div[@class='close']/i");
    By childWindowClosePopUp = By.xpath("//i[@class='icon-close closepopupbtn']");

    public SearchPage(WebDriver driver) {
        super(driver);
    }

    public String verifySearchPageTitle(){
        return driver.getTitle();
    }

    public SearchPage clickViewSeats(){
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,250)", "");
        driver.findElement(clickViewSeat).click();
        String parentWindow = driver.getWindowHandle();
        for(String winHandle : driver.getWindowHandles()){
            driver.switchTo().window(winHandle);
            driver.findElement(childWindowClosePopUp).click();
        }
        return this;
    }

    public SearchPage scrollToViewAvailableSeat(){
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,50)", "");
        return this;
    }
}
