package tests;

import org.Selenium.pom.base.BasePage;
import org.Selenium.pom.pages.HomePage;
import org.Selenium.pom.pages.SearchPage;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import org.Selenium.pom.Constants.constants;

import java.text.ParseException;
import java.time.Duration;
import java.util.Properties;

public class HomePageTest {
    public BasePage basePage;
    public WebDriver driver;
    public Properties prop;
    public HomePage homePage;
    public SearchPage searchPage;
    //this method will be executed before every @test method
    @BeforeMethod
    public void setUp(){
        basePage = new BasePage(driver);
        prop = basePage.initialize_Properties();
        driver = basePage.initialize_driver();
        driver.get(prop.getProperty("url"));
    }
    @Test
    public void verifyBus() throws InterruptedException, ParseException {
        HomePage homePage =new HomePage(driver);
        homePage.chooseFromCity(prop.getProperty("fromCitySuggestion"),prop.getProperty("fromCity"));
        homePage.chooseToCity(prop.getProperty("toCitySuggestion"),prop.getProperty("toCity"));
        homePage.datePicker();
        homePage.clickSearchBusBtn();
        verifySeatsinSearchPage();
    }


    public void verifySeatsinSearchPage(){
        SearchPage searchPage =new SearchPage(driver);
        searchPage.clickViewSeats();
        searchPage.scrollToViewAvailableSeat();
    }

  /* @AfterMethod
    public void tearDown(){
        driver.quit();
    } */
}
